//$ (function () {
//    var _width = $ (window).width ();
//    var _ziHao = 20 * (_width / 320);
//    if (_width < 641) {
//        $ ("#leekoh").css ({"font-size" : _ziHao + "px"})
//    }
//});