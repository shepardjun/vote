<?php
/*********文件描述*********
 * @last update 2019/3/15 18:20
 * @alter zhuangky(zhuangkeyong@sina.cn)
 * @version 1.0.0
 * 
 *
 * 功能简介：
 * @author zhuangky(zhuangkeyong@sina.cn)
 * @copyright zky
 * @version 2019/3/15 18:20 1.0.0
 */
namespace app\admin\model;

class Administrator extends Base
{
    protected $name = 'user';
}