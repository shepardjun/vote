<?php
namespace app\admin\controller;
use app\common\controller\Base;

class LoginBase extends Base{

    function _initialize()
    {
        parent::_initialize();
    }

    protected function response(){

    }
}