<?php
/*********文件描述*********
 * @last update 2019/3/22 9:23
 * @alter zhuangky(zhuangkeyong@sina.cn)
 * @version 1.0.0
 * 
 *
 * 功能简介：微信公众号等相关配置
 * @author zhuangky(zhuangkeyong@sina.cn)
 * @copyright zky
 * @version 2019/3/22 9:23
 */
return [
    'weixin_config' => [
        'app_id'          => 'wx2e0d29ec65b683c0',
        'app_secret'      => '727d910185cfa00cc7ff31c38e113586',
        'merchant_id'     => '1529383601',
        'merchant_secret' => 'zhichuantianxia20190321174500001',
    ]
];
