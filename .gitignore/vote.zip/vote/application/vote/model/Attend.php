<?php
/*********文件描述*********
 * @last update 2019/3/19 11:38
 * @alter zhuangky(zhuangkeyong@sina.cn)
 * @version 1.0.0
 *
 *
 * 功能简介：参赛人员mdl
 * @author zhuangky(zhuangkeyong@sina.cn)
 * @copyright zky
 * @version 2019/3/19 11:38
 */
namespace app\vote\model;

class Attend extends Base
{
    protected $name = 'attend';
}
